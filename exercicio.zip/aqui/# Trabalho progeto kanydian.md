# Trabalho progeto kanydian

Descriçao rapida do progeto

## Sensores

Descriçao dos sensores utilizados

- Sensor 1;
- Sensor 2;
- Sensor 3;

Link uteis:

[nome](url)

[nome](url)

[nome](url)