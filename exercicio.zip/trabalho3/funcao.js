function obterInformacoesDoInput() {
    // Obter o elemento de entrada pelo ID
    var nome = document.getElementById("nome").value;
    var endereco = document.getElementById("endereco").value;
    var email = document.getElementById("email").value;
    var telefone = document.getElementById("telefone").value;
    var CNPJ = document.getElementById("CNPJ").value;

    // Fazer algo com o valor obtido (por exemplo, exibi-lo em um alert)
    alert("O valor do input é: " + valorDoInput);

    document.getElementById("nome").value = "xxx";
  }
 